import { createStackNavigator } from "@react-navigation/stack";
import Home from "../pages/inicio";
import Login from "../pages/login";
import BottomRoutes from "./bottom.routes";

const Stack = createStackNavigator();

export default function Routes() {
  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen 
        name="Home" 
        component={Home} 
        options={{ headerShown: false }}
      />

      <Stack.Screen 
        name="Login" 
        component={Login} 
        options={{ headerShown: false }}
      />

      <Stack.Screen 
  name="BottomRoutes"
  component={BottomRoutes}
/>

    </Stack.Navigator>
  );
}
