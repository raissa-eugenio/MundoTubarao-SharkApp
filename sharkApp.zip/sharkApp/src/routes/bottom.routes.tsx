import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Login from '../pages/login';
import Cadastro from '../pages/cadastro';
import Principal from '../pages/principal';
import Sobre from '../pages/sobre';

const Tab = createBottomTabNavigator();

export default function BottomRoutes() {
  return (
    <Tab.Navigator>
      <Tab.Screen 
      name='Login' 
      component={Login} />

      <Tab.Screen 
      name='Cadastro' 
      component={Cadastro} />

       <Tab.Screen 
      name='Profile' 
      component={Principal} />

       <Tab.Screen 
      name='Profile' 
      component={Sobre} />
    </Tab.Navigator>
  );
}