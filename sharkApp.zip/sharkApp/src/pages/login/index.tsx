import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from "react-native";

export default function Login() {
  return (
    <ScrollView style={styles.container} contentContainerStyle={{ flexGrow: 1 }}>
      {/* HEADER IMAGE */}
      <View style={styles.header}>
        <Image
          source={require("../../assets/login.jpg")}
          style={styles.headerImage}
        />

        <View style={styles.headerTop}>
          <Text style={styles.headerTitle}>Mundo dos Tubarões</Text>
          <TouchableOpacity style={styles.loginMiniButton}>
            <Text style={styles.loginMiniText}>Login</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* CARD LOGIN */}
      <View style={styles.loginCard}>
       <TouchableOpacity >
  <Text>Entrar</Text>
</TouchableOpacity>

        <Text style={styles.label}>Acesse sua conta do Mundo dos Tubarões</Text>

        <TextInput
          placeholder="Email"
          placeholderTextColor="#999"
          style={styles.input}
        />

        <TextInput
          placeholder="Senha"
          placeholderTextColor="#999"
          secureTextEntry
          style={styles.input}
        />

        <TouchableOpacity style={styles.primaryButton}>
          <Text style={styles.primaryButtonText}>Entrar</Text>
        </TouchableOpacity>

        <Text style={styles.orText}>ou continue com</Text>

        <TouchableOpacity style={styles.googleButton}>
          <Text style={styles.googleButtonText}>Google</Text>
        </TouchableOpacity>

        <Text style={styles.footerSmall}>
          Não tem conta? <Text style={styles.link}>Cadastre-se</Text>
        </Text>
      </View>

      {/* BOTTOM INFO */}
      <View style={styles.bottomInfo}>
        <Text style={styles.bottomTitle}>Explore o mundo marinho</Text>
        <Text style={styles.bottomText}>
          Conheça curiosidades, espécies fascinantes e descubra a importância
          dos tubarões para o equilíbrio dos oceanos.
        </Text>
      </View>
    </ScrollView>
  );
}

/* ================= STYLES ================= */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f3f6fb",
  },

  /* HEADER */
  header: {
    height: 220,
  },
  headerImage: {
    width: "100%",
    height: "100%",
  },
  headerTop: {
    position: "absolute",
    top: 40,
    left: 16,
    right: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  loginMiniButton: {
    backgroundColor: "#1e90ff",
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 16,
  },
  loginMiniText: {
    color: "#fff",
  },

  /* CARD */
  loginCard: {
    backgroundColor: "#fff",
    marginHorizontal: 16,
    borderRadius: 20,
    padding: 20,
    marginTop: -40,
    elevation: 6,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 8,
    textAlign: "center",
  },
  label: {
    color: "#555",
    fontSize: 14,
    textAlign: "center",
    marginBottom: 16,
  },
  input: {
    backgroundColor: "#f1f1f1",
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },

  primaryButton: {
    backgroundColor: "#1e90ff",
    paddingVertical: 12,
    borderRadius: 20,
    alignItems: "center",
    marginTop: 8,
  },
  primaryButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },

  orText: {
    textAlign: "center",
    color: "#777",
    marginVertical: 12,
  },

  googleButton: {
    borderWidth: 1,
    borderColor: "#ddd",
    paddingVertical: 12,
    borderRadius: 20,
    alignItems: "center",
  },
  googleButtonText: {
    color: "#333",
  },

  footerSmall: {
    textAlign: "center",
    marginTop: 16,
    color: "#666",
  },
  link: {
    color: "#1e90ff",
    fontWeight: "bold",
  },

  /* BOTTOM */
  bottomInfo: {
    backgroundColor: "#0a2a43",
    marginTop: 20,
    padding: 20,
  },
  bottomTitle: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 6,
  },
  bottomText: {
    color: "#cdd8e3",
    fontSize: 13,
  },
});
